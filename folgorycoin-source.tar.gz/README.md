Development moved to https://gitlab.com/blacknet-ninja

https://folgorycoin.org/ aims to continue on FolgoryCoin chain.
